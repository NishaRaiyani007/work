// Function to change main image on thumbnail click
function changeImage(imageSrc) {
    document.getElementById('main-image').src = imageSrc;
}

// Dynamic total price update
$(document).ready(function() {
    $('#quantity').on('change', function() {
        let price = 100; // example price
        let quantity = $(this).val();
        let totalPrice = price * quantity;
        $('#total-price').text(totalPrice.toFixed(2));
    });
});

// Fly to cart animation (optional)
$('.btn-primary').on('click', function() {
    let cart = $('.cart');
    let imgToDrag = $(this).closest('.card').find('img').eq(0);

    if (imgToDrag) {
        let imgClone = imgToDrag.clone()
            .offset({
                top: imgToDrag.offset().top,
                left: imgToDrag.offset().left
            })
            .css({
                'opacity': '0.5',
                'position': 'absolute',
                'height': '150px',
                'width': '150px',
                'z-index': '100'
            })
            .appendTo($('body'))
            .animate({
                'top': cart.offset().top + 10,
                'left': cart.offset().left + 10,
                'width': 75,
                'height': 75
            }, 1000, 'easeInOutExpo');
        
        imgClone.animate({'width': 0, 'height': 0}, function() {
            $(this).detach();
        });
    }
});
